<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8"> <!-- Don't Edit -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Don't Edit -->
    <meta name="description" content="Wangock - Обычный пользователь интернета, изучаю PHP."> <!-- Description page -->
    <meta name="keywords" content="Вангок, Wangock"> <!-- KeyWords page -->
    <meta name="author" content="Wangock"> <!-- Page author -->
    <meta name="copyright" content="Wangock"> <!-- Copyright page -->
    <title><?php echo $title; ?></title> <!-- Don't Edit -->
    <link rel="stylesheet" href="/assets/styles/main.css"> <!-- CSS -->
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/favicon/apple-touch-icon.png"> <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon/favicon-32x32.png"> <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/favicon/favicon-16x16.png"> <!-- Favicon -->
    <link rel="manifest" href="/assets/favicon/site.webmanifest"> <!-- Favicon -->
    <link rel="mask-icon" href="/assets/favicon/safari-pinned-tab.svg" color="#474747"> <!-- Favicon -->
    <link rel="shortcut icon" href="/assets/favicon/favicon.ico"> <!-- Favicon -->
    <meta name="msapplication-TileColor" content="#73cce4"> <!-- Favicon -->
    <meta name="msapplication-config" content="/assets/favicon/browserconfig.xml"> <!-- Favicon -->
    <meta name="theme-color" content="#97c3ff"> <!-- Favicon -->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script> <!-- https://ionic.io/ionicons -->
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script> <!-- https://ionic.io/ionicons -->
</head>