<?php 
$title = "Document"; // Page title
require_once('/OSPanel/domains/wangock.pro/modules/blocks/head.php'); // path to head.php file
?>
<body>

</body>
</html>